document.getElementById("searchButton").addEventListener("click", function () {
  var searchTerm = document.getElementById("searchBar").value;
  console.log("Search for:", searchTerm);
  // Add search functionality or redirection here
});

document.getElementById("loginButton").addEventListener("click", function () {
  alert("Login button clicked");
  // 여기에 로그인 관련 기능 또는 모달 표시 코드 추가
});
