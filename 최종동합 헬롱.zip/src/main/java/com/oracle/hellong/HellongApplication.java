package com.oracle.hellong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellongApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellongApplication.class, args);
	}

}
