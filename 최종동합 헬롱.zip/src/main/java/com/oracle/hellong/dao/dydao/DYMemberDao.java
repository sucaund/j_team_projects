package com.oracle.hellong.dao.dydao;

import java.util.List;

import com.oracle.hellong.model.Member;

public interface DYMemberDao {



}