package com.oracle.hellong.dao.jhdao;

import java.util.List;

import com.oracle.hellong.model.GymOrder;

public interface GymOrderDao {


}
