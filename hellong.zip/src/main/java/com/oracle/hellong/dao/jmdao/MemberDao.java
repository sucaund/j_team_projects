package com.oracle.hellong.dao.jmdao;


public interface MemberDao {


}
