package com.oracle.hellong.dao.dydao;

public interface DYMemberDao {

}
