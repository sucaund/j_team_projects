package com.oracle.hellong.dao.jhdao;

public interface GymOrderDao {

}
