package com.oracle.hellong.model;

import lombok.Data;

@Data
public class Zzim { //찜 zzim
     private int g_id; //체육관id pk nn f
       private int m_number; //멤버번호 pk nn  f

}