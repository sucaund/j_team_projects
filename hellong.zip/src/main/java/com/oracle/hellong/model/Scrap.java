package com.oracle.hellong.model;

import lombok.Data;

@Data
public class Scrap { //스크랩 scrap
    private int m_number; //멤버번호 pk f nn 
       private int b_number; //게시글번호  pk f nn
}