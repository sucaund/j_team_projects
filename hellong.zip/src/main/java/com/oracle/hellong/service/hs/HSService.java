package com.oracle.hellong.service.hs;

public interface HSService {

}
