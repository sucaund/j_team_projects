package com.oracle.hellong.service.jj;

public interface JJService {

}
