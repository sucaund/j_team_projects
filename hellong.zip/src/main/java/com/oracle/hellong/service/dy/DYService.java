package com.oracle.hellong.service.dy;

public interface DYService {

}
