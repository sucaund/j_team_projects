package com.oracle.hellong.service.jj;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JJServiceImpl implements JJService {

}
