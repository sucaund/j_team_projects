package com.oracle.hellong.service.jm;





public interface JMService {
	

}
