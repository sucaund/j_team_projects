package com.oracle.hellong.service.jh;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JHServiceImpl implements JHService {

}
