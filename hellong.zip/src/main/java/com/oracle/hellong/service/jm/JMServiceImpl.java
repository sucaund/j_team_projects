package com.oracle.hellong.service.jm;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import com.oracle.hellong.model.Emp;
//import com.oracle.hellong.model.EmpDept;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional //jpa에서 사용
public class JMServiceImpl implements JMService {


}
