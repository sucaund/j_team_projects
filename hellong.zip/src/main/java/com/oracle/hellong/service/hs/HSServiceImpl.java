package com.oracle.hellong.service.hs;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HSServiceImpl implements HSService {

}
