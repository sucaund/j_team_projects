package com.oracle.hellong.service.jh;

public interface JHService {

}
