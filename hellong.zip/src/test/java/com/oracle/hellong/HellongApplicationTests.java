package com.oracle.hellong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellongApplicationTests {

	@Test
	void contextLoads() {
	}

}
